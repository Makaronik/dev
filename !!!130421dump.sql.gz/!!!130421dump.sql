--
-- PostgreSQL database dump
--

-- Dumped from database version 12.2
-- Dumped by pg_dump version 12.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: book; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.book (
    id integer NOT NULL,
    name character varying(255),
    art character varying(255),
    created_date timestamp without time zone,
    autor character varying(255),
    status boolean DEFAULT true,
    condition character varying(255) DEFAULT NULL::character varying
);


ALTER TABLE public.book OWNER TO postgres;

--
-- Name: book_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.book_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.book_id_seq OWNER TO postgres;

--
-- Name: book_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.book_id_seq OWNED BY public.book.id;


--
-- Name: client; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.client (
    id integer NOT NULL,
    name character varying(255),
    series integer,
    number integer
);


ALTER TABLE public.client OWNER TO postgres;

--
-- Name: client_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.client_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.client_id_seq OWNER TO postgres;

--
-- Name: client_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.client_id_seq OWNED BY public.client.id;


--
-- Name: order_b; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.order_b (
    id integer NOT NULL,
    order_id integer,
    book_id integer
);


ALTER TABLE public.order_b OWNER TO postgres;

--
-- Name: order_b_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.order_b_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.order_b_id_seq OWNER TO postgres;

--
-- Name: order_b_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.order_b_id_seq OWNED BY public.order_b.id;


--
-- Name: order_book; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.order_book (
    order_id integer,
    book_id integer
);


ALTER TABLE public.order_book OWNER TO postgres;

--
-- Name: orders; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.orders (
    id integer NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    status boolean DEFAULT true,
    client_id integer,
    set_worker_id integer,
    get_worker_id integer,
    deadline timestamp without time zone
);


ALTER TABLE public.orders OWNER TO postgres;

--
-- Name: orders_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.orders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.orders_id_seq OWNER TO postgres;

--
-- Name: orders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.orders_id_seq OWNED BY public.orders.id;


--
-- Name: user; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."user" (
    id integer NOT NULL,
    username character varying(255) NOT NULL,
    password character varying(255) NOT NULL,
    auth_key character varying(255) DEFAULT NULL::character varying
);


ALTER TABLE public."user" OWNER TO postgres;

--
-- Name: user_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_id_seq OWNER TO postgres;

--
-- Name: user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.user_id_seq OWNED BY public."user".id;


--
-- Name: worker; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.worker (
    id integer NOT NULL,
    name character varying(255),
    "position" character varying(255)
);


ALTER TABLE public.worker OWNER TO postgres;

--
-- Name: worker_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.worker_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.worker_id_seq OWNER TO postgres;

--
-- Name: worker_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.worker_id_seq OWNED BY public.worker.id;


--
-- Name: book id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.book ALTER COLUMN id SET DEFAULT nextval('public.book_id_seq'::regclass);


--
-- Name: client id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.client ALTER COLUMN id SET DEFAULT nextval('public.client_id_seq'::regclass);


--
-- Name: order_b id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_b ALTER COLUMN id SET DEFAULT nextval('public.order_b_id_seq'::regclass);


--
-- Name: orders id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders ALTER COLUMN id SET DEFAULT nextval('public.orders_id_seq'::regclass);


--
-- Name: worker id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.worker ALTER COLUMN id SET DEFAULT nextval('public.worker_id_seq'::regclass);


--
-- Data for Name: book; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.book (id, name, art, created_date, autor, status, condition) FROM stdin;
8	Стивен Кинг: Сияние	124124125	2021-04-07 09:41:55.030599	Стивен Кинг	f	\N
13	Стивен Кинг: Будет кровь	14124124	2021-04-08 13:14:50.05925	Стивен	t	\N
14	Разговор отца с сыном. Имей совесть и делай, что хочешь!	p7165601	\N	Михаил Жванецкий	f	
7	Стивен Кинг: Будет кровь	1241242	2021-04-07 09:09:59	Стивен Кинг	t	
1	Федор Достоевский: Игрок	p1581942	\N	Федор Достоевский	t	\N
18	Эрих Фромм: Искусство любить	p191224	2021-04-10 10:18:43.840006	Эрих Фромм	t	\N
17	Джордж Оруэлл: 1984	p191342	2021-04-10 10:18:43.833797	Джордж Оруэлл	t	\N
16	Уильям Голдинг: Повелитель мух	p191233	2021-04-08 16:15:39.460565	Уильям Голдинг	t	\N
15	Евгений Водолазкин: Лавр	p189705	2021-04-08 16:08:24.530338	Евгений Водолазкин	f	
12	Оскар Уайльд: Портрет Дориана Грея	p1597309	\N	Оскар Уайльд	t	\N
11	Уолтер Тевис: Ход королевы	p5898821	2021-04-08 06:11:09.311156	Уолтер Тевис	t	\N
10	Яд и корона	13123123	2021-04-08 06:10:54.795277	Дрюон Морис 	t	\N
9	Джейн Остен: Гордость и предубеждение	42323523	2021-04-07 10:04:52.380961	Джейн Остен	t	\N
6	Маленький принц	p1401551	2021-04-07 07:51:16.648425	Сент-Экзюпери Антуан де 	t	\N
5	Федор Достоевский: Идиот	p59135132	2021-04-07 07:50:53.851825	Федор Достоевский	f	\N
4	Фрэнсис Фицджеральд: Великий Гэтсби	p59267242	2021-04-07 07:40:38.755856	Фрэнсис Фицджеральд	t	\N
\.


--
-- Data for Name: client; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.client (id, name, series, number) FROM stdin;
1	Иванов М.С.	1209	204735
2	Петров И.В.	1207	478954
3	Сидоров А.В.	1209	358661
\.


--
-- Data for Name: order_b; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.order_b (id, order_id, book_id) FROM stdin;
\.


--
-- Data for Name: order_book; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.order_book (order_id, book_id) FROM stdin;
1	1
1	9
2	6
3	10
3	11
4	14
4	13
\N	15
\N	12
\N	11
\N	10
10	14
10	13
10	12
10	11
10	10
10	9
10	16
16	17
17	16
\.


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.orders (id, created_at, updated_at, status, client_id, set_worker_id, get_worker_id, deadline) FROM stdin;
1	2021-04-07 09:09:59	2021-04-07 09:09:59	t	1	1	\N	2021-04-07 09:09:59
2	2021-04-07 09:09:59	2021-04-07 09:09:59	t	2	1	\N	2021-04-07 09:09:59
3	2021-04-07 09:09:59	2021-04-09 07:47:57.342912	t	3	1	\N	2021-04-07 09:09:59
4	2021-04-09 10:52:06.59907	\N	t	\N	\N	\N	\N
5	2021-04-09 10:54:04.49766	\N	t	\N	\N	\N	\N
7	2021-04-09 10:55:39.509302	\N	t	\N	\N	\N	\N
8	2021-04-09 10:56:20.853477	\N	t	\N	\N	\N	\N
9	2021-04-09 21:03:05.191828	\N	t	\N	\N	\N	\N
10	2021-04-09 21:04:58.675643	\N	t	\N	\N	\N	\N
11	2021-04-09 21:05:34.811165	\N	t	\N	\N	\N	\N
12	2021-04-10 14:37:34.804326	\N	t	1	1	\N	\N
13	2021-04-11 15:49:25.172954	\N	t	1	1	\N	\N
14	2021-04-11 15:51:04.502831	\N	t	1	1	\N	\N
16	2021-04-12 16:22:32.813932	\N	t	3	1	\N	\N
17	2021-04-13 04:20:48.827264	\N	t	1	1	\N	\N
18	2021-04-13 04:41:04.859634	\N	t	1	1	\N	2021-04-13 08:40:00
\.


--
-- Data for Name: user; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."user" (id, username, password, auth_key) FROM stdin;
1	admin	$2y$13$3s9iaVzGBbD3F2g51Kil4OAhceoeM4/VtWCkvYVvHZxLp40XzI9gy	q2SpkvynkCEpZhxG-AzgrIFLM993EdQF
\.


--
-- Data for Name: worker; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.worker (id, name, "position") FROM stdin;
1	Глебов Б.А.	библиотекарь
2	Акунин Б.	библиотекарь
3	Виницкий М.	зав. библиотекой
\.


--
-- Name: book_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.book_id_seq', 18, true);


--
-- Name: client_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.client_id_seq', 3, true);


--
-- Name: order_b_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.order_b_id_seq', 1, false);


--
-- Name: orders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.orders_id_seq', 18, true);


--
-- Name: user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.user_id_seq', 1, false);


--
-- Name: worker_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.worker_id_seq', 3, true);


--
-- Name: book book_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.book
    ADD CONSTRAINT book_pkey PRIMARY KEY (id);


--
-- Name: client client_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.client
    ADD CONSTRAINT client_pkey PRIMARY KEY (id);


--
-- Name: order_b order_b_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_b
    ADD CONSTRAINT order_b_pkey PRIMARY KEY (id);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- Name: user user_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_pkey PRIMARY KEY (id);


--
-- Name: worker worker_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.worker
    ADD CONSTRAINT worker_pkey PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

